# Diverse Verification

Public preprint source for:

> Three Agents Are Not Three Verifiers: Measuring Common-Mode Failure in LLM Verification

## Build

```bash
python3 -m pip install -r requirements.txt
python3 make_figures.py
pdflatex paper.tex
bibtex paper
pdflatex paper.tex
pdflatex paper.tex
```

The NeurIPS 2026 VERICODEGEN workshop style is included without modification.
`results_summary.json` contains the aggregate values used by the manuscript,
and `make_figures.py` regenerates the included figures.
