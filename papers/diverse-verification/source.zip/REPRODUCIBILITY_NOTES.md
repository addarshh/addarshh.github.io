# Reproducibility Notes

These notes support the paper without adding request IDs, run IDs, or commit
metadata to the manuscript.

## Controlled study

- Candidates: 64 from 23 task groups.
- Split: 17 calibration candidates and 47 held-out candidates from 15 groups.
- Models: Claude Sonnet 5, Claude Opus 5, Qwen3 Coder, DeepSeek V3.2,
  Devstral 2, and GPT-5.6 Terra.
- Access period: August 2026.
- Run identities: 17, 29, and 43.
- Open-weight decoding: temperature 0 with the corresponding seed.
- Claude decoding: extended thinking, no temperature parameter.
- Terra decoding: high reasoning effort, no temperature parameter, inference
  profile `us.openai.gpt-5.6-terra`.
- Prompt: fixed across models; labels and checker results hidden.
- Initial output cap: 500 tokens.
- Terra recovery: 45 truncated cells rerun with lower reasoning effort and a
  larger output cap; only complete responses are canonical.
- Final matrix: 1,152 successful judgments and zero parse failures.

## Policy definitions

- Single Terra and Single Qwen: direct verdict at run identity 17.
- Three Sonnet: run identities 17, 29, and 43; accept with at least two votes.
- Cross-model: Sonnet, Qwen, and DeepSeek at run identity 17; accept with at
  least two votes.
- Selected trio: DeepSeek run 43, Devstral run 17, and Opus run 29.
- Panel selection: enumerate all three-member panels among 18 model-run
  identities on the 17 calibration candidates.
- Selection score: 0.4 majority accuracy + 0.3 (1 - observed joint failure) +
  0.2 mean member accuracy + 0.1 represented-family count.
- Disagreement-selected: selected trio with majority acceptance.
- Covariance-aware: majority acceptance plus minimum member confidence 0.6.
- All panel choices were frozen before held-out evaluation.

## Repository study

- Repositories: 47.
- Candidates collected: 141.
- Candidates analyzed: 130, including 71 correct and 59 wrong.
- Downstream checks available: 89 candidates.
- Reviewer decisions: 108 direct agreements, 22 decisive-plus-ambiguous
  cases retained, and 11 direct correct-versus-wrong disagreements excluded.
- Reviewer agreement: Cohen's kappa 0.73.
- Routing trigger: disagreement between Qwen and Sonnet, observed on 34 of
  130 candidates.
- Pytest route: pass or fail becomes the routed verdict.
- Model-only route: DeepSeek supplies the routed verdict.
- Expected costs: 1.91 units for pytest routing and 2.02 for model routing.

## Adaptive study

- Generator: Claude Sonnet 4.7.
- Operators: return substitution, boundary shift, branch flip, off-by-one.
- Cap: 500 attempts per policy.
- Stop: 20 acceptances, or 100 consecutive rejections after at least 15
  acceptances.
- Deduplication: SHA-256 of candidate source.
- Evaluator: modified pytest with hidden regression tests, downstream tests
  when available, and one expert semantic review, blinded to accepting panel.

## Statistics and compute

- Bootstrap replicates: 10,000.
- Controlled resampling unit: held-out task group.
- Repository resampling unit: repository.
- Cost reference: median Sonnet 5 input plus output token count.
- Inference concurrency: at most 10 requests per model.
- Checking host: Ubuntu 24.04, 16 vCPUs, 64 GB RAM, no GPU.
- Wall-clock time: 6.4 hours controlled, 3.2 hours repository, 14.8 hours
  adaptive, 2.1 hours native checking, and 0.3 hours analysis.
- Total: 26.8 wall-clock hours and 428.8 provisioned vCPU-hours.
- Tools: Verus 0.2689, Lean 4.33.0, Z3 4.15.4, cvc5 1.3.4, pytest 8.3.1,
  and Python 3.12.7.
