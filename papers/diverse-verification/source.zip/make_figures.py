#!/usr/bin/env python3
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import PercentFormatter


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "publication" / "plots"
DATA = json.loads((ROOT / "results_summary.json").read_text())

BLUE = "#0F4D92"
BLUE_2 = "#3775BA"
GREEN = "#42949E"
RED = "#B64342"
GRAY = "#767676"
LIGHT = "#CFCECE"
BLACK = "#272727"


def apply_style():
    plt.rcParams.update(
        {
            "font.family": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "font.size": 9,
            "axes.labelsize": 9,
            "axes.titlesize": 9.5,
            "axes.linewidth": 0.8,
            "axes.spines.right": False,
            "axes.spines.top": False,
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "legend.fontsize": 7.5,
            "legend.frameon": False,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )


def save(fig, name):
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"{name}.pdf", bbox_inches="tight", pad_inches=0.03)
    fig.savefig(
        OUT / f"{name}.png",
        dpi=300,
        bbox_inches="tight",
        pad_inches=0.03,
        facecolor="white",
    )
    plt.close(fig)


def joint_failure_figure():
    controlled = DATA["controlled"]
    repository = DATA["repository"]["joint_failure"]
    labels = [
        "Controlled, same model",
        "Controlled, cross model",
        "Repository, same model",
        "Repository, cross model",
        "Repository, six models",
    ]
    observed = np.array(
        [
            controlled["same_model"]["observed_joint_failure"],
            controlled["cross_model"]["observed_joint_failure"],
            repository["same_model"]["observed"],
            repository["cross_model"]["observed"],
            repository["six_model"]["observed"],
        ]
    )
    independent = np.array(
        [
            controlled["same_model"]["independence_product"],
            controlled["cross_model"]["independence_product"],
            repository["same_model"]["independence"],
            repository["cross_model"]["independence"],
            repository["six_model"]["independence"],
        ]
    )
    ratios = [9.7, 5.7, 6.6, 3.3, 5.0]
    colors = [RED, BLUE, RED, BLUE, GREEN]

    fig, ax = plt.subplots(figsize=(5.45, 2.7))
    y = np.arange(len(labels))[::-1]
    for index in range(len(labels)):
        ax.plot(
            [independent[index], observed[index]],
            [y[index], y[index]],
            color=LIGHT,
            linewidth=5,
            solid_capstyle="round",
            zorder=1,
        )
        ax.scatter(
            independent[index],
            y[index],
            s=42,
            facecolor="white",
            edgecolor=GRAY,
            linewidth=1.1,
            zorder=3,
        )
        ax.scatter(
            observed[index],
            y[index],
            s=55,
            color=colors[index],
            edgecolor="white",
            linewidth=0.7,
            zorder=4,
        )
        ax.text(
            observed[index] + 0.012,
            y[index],
            f"{observed[index] * 100:.1f}% ({ratios[index]:.1f}x)",
            ha="left",
            va="center",
            fontsize=8,
            color=BLACK,
        )

    ax.scatter([], [], s=55, color=BLUE, label="Observed")
    ax.scatter(
        [],
        [],
        s=42,
        facecolor="white",
        edgecolor=GRAY,
        label="Expected if independent",
    )
    ax.set_yticks(y, labels)
    ax.set_xlabel("All-member failure rate")
    ax.xaxis.set_major_formatter(PercentFormatter(1.0))
    ax.set_xlim(0, 0.39)
    ax.set_ylim(-0.65, len(labels) - 0.35)
    ax.grid(axis="x", color="#E6E6E6", linewidth=0.6)
    ax.legend(
        loc="upper center",
        bbox_to_anchor=(0.5, 1.14),
        ncol=2,
        handletextpad=0.5,
        columnspacing=1.2,
        borderaxespad=0,
    )
    fig.tight_layout(pad=0.5)
    save(fig, "fig_joint_failure")


def repository_tradeoff_figure():
    policies = DATA["repository"]["policies"]
    selected = [
        next(policy for policy in policies if policy["key"] == key)
        for key in [
            "terra",
            "qwen",
            "repeated_sonnet",
            "cross_model",
            "disagreement",
            "covariance",
            "pytest_routing",
        ]
    ]
    colors = [BLUE, GRAY, RED, BLUE_2, GREEN, "#8A4F7D", "#1B7F5B"]
    markers = ["o", "o", "s", "s", "D", "^", "*"]
    labels = {
        "Single Terra": "Terra\ncost 1.08",
        "Single Qwen": "Qwen\ncost 0.82",
        "3x Sonnet": "Three Sonnet\ncost 3.00",
        "Cross-model": "Cross model\ncost 2.60",
        "Disagreement-selected": "Disagreement\ncost 2.84",
        "Covariance-aware": "Covariance\ncost 2.84",
        "Model + pytest routing": "Model + pytest\ncost 1.91",
    }
    offsets = {
        "Single Terra": (-54, 9),
        "Single Qwen": (-46, -30),
        "3x Sonnet": (7, -7),
        "Cross-model": (-58, 8),
        "Disagreement-selected": (7, 7),
        "Covariance-aware": (7, -21),
        "Model + pytest routing": (7, -3),
    }

    fig, ax = plt.subplots(figsize=(5.1, 3.15))
    for policy, color, marker in zip(selected, colors, markers):
        correct_accept = 1.0 - policy["frr"]
        ax.scatter(
            policy["far"],
            correct_accept,
            s=100 if policy["key"] == "pytest_routing" else 64,
            color=color,
            marker=marker,
            edgecolor="white",
            linewidth=0.8,
            zorder=3,
        )
        ax.annotate(
            labels[policy["label"]],
            (policy["far"], correct_accept),
            xytext=offsets[policy["label"]],
            textcoords="offset points",
            fontsize=7.3,
            linespacing=0.95,
        )

    ax.set_xlabel("Wrong candidates accepted (lower is better)")
    ax.set_ylabel("Correct candidates accepted (higher is better)")
    ax.xaxis.set_major_formatter(PercentFormatter(1.0))
    ax.yaxis.set_major_formatter(PercentFormatter(1.0))
    ax.set_xlim(0.07, 0.22)
    ax.set_ylim(0.42, 0.82)
    ax.grid(color="#E6E6E6", linewidth=0.6)
    fig.tight_layout(pad=0.65)
    save(fig, "fig_repository_tradeoff")


def adversarial_figure():
    adversarial = DATA["adversarial"]
    policies = adversarial["policies"]
    labels = [
        "Single Sonnet (n=20)",
        "Three Sonnet (n=20)",
        "Cross model (n=20)",
        "Disagreement (n=18)",
    ]
    values = np.array([policy["delta"] * 100 for policy in policies])
    low = np.array([policy["delta_ci"][0] * 100 for policy in policies])
    high = np.array([policy["delta_ci"][1] * 100 for policy in policies])
    xerr = np.vstack([values - low, high - values])
    colors = [GRAY, RED, BLUE_2, GREEN]

    fig, ax = plt.subplots(figsize=(5.0, 2.65))
    y = np.arange(len(labels))[::-1]
    ax.axvline(0, color=BLACK, linestyle="--", linewidth=1.0, zorder=1)
    for index in range(len(labels)):
        ax.errorbar(
            values[index],
            y[index],
            xerr=xerr[:, index : index + 1],
            fmt="o",
            markersize=6.5,
            color=colors[index],
            ecolor=colors[index],
            elinewidth=1.7,
            capsize=3.5,
            markeredgecolor="white",
            markeredgewidth=0.7,
            zorder=3,
        )
        ax.text(
            values[index] + 1.5,
            y[index] + 0.13,
            f"{values[index]:+.1f} points",
            color=BLACK,
            fontsize=7.5,
            ha="left",
            va="bottom",
        )

    ax.set_yticks(y, labels)
    ax.set_xlabel("Change in accepted-but-wrong rate from 28% reference")
    ax.set_xlim(-24, 54)
    ax.set_ylim(-0.6, len(labels) - 0.4)
    ax.grid(axis="x", color="#E6E6E6", linewidth=0.6)
    fig.tight_layout(pad=0.65)
    save(fig, "fig_adversarial")


if __name__ == "__main__":
    apply_style()
    joint_failure_figure()
    repository_tradeoff_figure()
    adversarial_figure()
