#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

uv run \
  --with "matplotlib>=3.9" \
  --with "numpy>=2.0" \
  --with "scipy>=1.14" \
  python publication/make_results.py \
  > publication/recomputed_results.txt

uv run \
  --with "matplotlib>=3.9" \
  --with "numpy>=2.0" \
  python publication/make_skill_figures.py

echo "Recomputed statistics and figures under publication/."
