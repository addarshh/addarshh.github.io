# Anonymous IntentShield V5 Supplement

This supplement contains the task-level aggregate data and scripts used to reproduce
the statistics and figures reported in the paper.

## Included

- `figure_inputs/`: primary, downstream, transfer, and diagnostic aggregate tables.
- `publication/make_results.py`: statistical recomputation.
- `publication/make_skill_figures.py`: publication-figure generation.
- `reproduce.sh`: one-command reproduction.

## Current Reproduction Scope

The included files reproduce every reported aggregate count, effect, interval,
statistical test, and figure without making provider calls.

Full replay of the model-facing experiments requires the additional anonymized
prompts, responses, verifier outputs, request metadata, and runtime information.
Those replay materials are not included in this draft supplement.

## Data Structure

- Primary rows use VeriContest task as the independent unit.
- Each primary task contains 12 outcomes per policy from four model families and
  three repeated runs.
- Downstream rows use task as the independent unit and contain three implementation
  attempts per condition.
- Transfer and mechanism tables are explicitly descriptive where confirmatory
  inference is unavailable.

## License

Pending author confirmation before submission.
