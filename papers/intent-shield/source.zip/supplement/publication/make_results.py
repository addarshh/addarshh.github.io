#!/usr/bin/env python3
"""Recompute V3 aggregate statistics and generate publication figures."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import binomtest, wilcoxon

plt.rcParams["pdf.fonttype"] = 42
plt.rcParams["ps.fonttype"] = 42


ROOT = Path(__file__).resolve().parent
PLOTS = ROOT / "plots"
PLOTS.mkdir(parents=True, exist_ok=True)

TASKS = [
    "cf124A", "cf492A", "cf92A", "cf271A", "cf519C", "cf4A",
    "cf110A", "cf617A", "cf50A", "cf47A", "cf318A", "cf486A",
]
DIRECT = np.array([9, 8, 7, 6, 5, 11, 10, 9, 2, 6, 5, 7])
INTENT = np.array([3, 3, 2, 2, 2, 7, 6, 5, 4, 1, 1, 3])
PHASE = DIRECT.copy()

DOWNSTREAM_TASKS = [
    "cf124A", "cf492A", "cf92A", "cf271A", "cf519C", "cf4A",
    "cf110A", "cf617A", "cf50A", "cf47A", "cf318A", "cf486A",
    "cf200A", "cf228A", "cf263A", "cf337A",
]
ORIGINAL = np.array([0, 0, 0, 1, 0, 3, 1, 2, 3, 1, 0, 0, 1, 0, 1, 1])
PHASE_REVISED = np.array([3, 3, 2, 3, 3, 3, 2, 2, 3, 2, 3, 2, 2, 2, 2, 2])
INTENT_REVISED = np.array([2, 2, 1, 2, 2, 3, 2, 2, 3, 2, 2, 1, 2, 2, 1, 1])

def bootstrap_ci(delta: np.ndarray, seed: int = 20260911) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    sampled = delta[rng.integers(0, len(delta), size=(100_000, len(delta)))]
    return tuple(np.percentile(sampled.mean(axis=1), [2.5, 97.5]))


def save_task_effects() -> None:
    effects = (DIRECT - INTENT) / 12 * 100
    colors = ["#2166ac"] * 5 + ["#4d9221"] * 7
    colors[TASKS.index("cf50A")] = "#b2182b"

    fig, ax = plt.subplots(figsize=(7.1, 4.6))
    y = np.arange(len(TASKS))
    ax.barh(y, effects, color=colors, height=0.68)
    ax.axvline(0, color="#333333", linewidth=0.9)
    ax.set_yticks(y, TASKS)
    ax.invert_yaxis()
    ax.set_xlabel("Direct minus IntentShield success rate (percentage points)")
    ax.set_xlim(-22, 57)
    ax.grid(axis="x", color="#dddddd", linewidth=0.7)
    ax.set_axisbelow(True)
    for yi, value in zip(y, effects):
        offset = 1.2 if value >= 0 else -1.2
        align = "left" if value >= 0 else "right"
        ax.text(value + offset, yi, f"{value:+.1f}", va="center", ha=align, fontsize=8)
    for spine in ("top", "right", "left"):
        ax.spines[spine].set_visible(False)
    fig.tight_layout()
    fig.savefig(PLOTS / "task_effects_v2.pdf", bbox_inches="tight")
    fig.savefig(PLOTS / "task_effects_v2.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def save_downstream_heatmap() -> None:
    matrix = np.column_stack([ORIGINAL, INTENT_REVISED, PHASE_REVISED])
    fig, ax = plt.subplots(figsize=(6.2, 5.6))
    image = ax.imshow(matrix, cmap="YlGn", vmin=0, vmax=3, aspect="auto")
    ax.set_xticks([0, 1, 2], ["Original", "IS-revised", "Phase-revised"])
    ax.set_yticks(np.arange(len(DOWNSTREAM_TASKS)), DOWNSTREAM_TASKS)
    for row in range(matrix.shape[0]):
        for col in range(matrix.shape[1]):
            color = "white" if matrix[row, col] >= 3 else "#222222"
            ax.text(col, row, f"{matrix[row, col]}/3", ha="center", va="center",
                    color=color, fontsize=8)
    cbar = fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label("Successful attempts")
    ax.set_xlabel("Specification condition")
    ax.set_ylabel("Task")
    fig.tight_layout()
    fig.savefig(PLOTS / "downstream_tasks_v2.pdf", bbox_inches="tight")
    fig.savefig(PLOTS / "downstream_tasks_v2.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def report() -> None:
    primary_delta = (DIRECT - INTENT) / 12
    print("PRIMARY")
    print("totals", DIRECT.sum(), INTENT.sum(), PHASE.sum())
    print("effect", primary_delta.mean())
    print("bootstrap", bootstrap_ci(primary_delta))
    print("sign", binomtest(np.sum(primary_delta > 0), len(primary_delta), 0.5).pvalue)
    print("wilcoxon", wilcoxon(primary_delta, method="exact").pvalue)

    print("\nDOWNSTREAM")
    for label, left, right in [
        ("phase-original", PHASE_REVISED, ORIGINAL),
        ("intent-original", INTENT_REVISED, ORIGINAL),
        ("phase-intent", PHASE_REVISED, INTENT_REVISED),
    ]:
        delta = (left - right) / 3
        informative = delta[delta != 0]
        print(
            label,
            "effect", delta.mean(),
            "wins", np.sum(delta > 0),
            "ties", np.sum(delta == 0),
            "losses", np.sum(delta < 0),
            "sign", binomtest(np.sum(informative > 0), len(informative), 0.5).pvalue,
            "bootstrap", bootstrap_ci(delta),
        )

if __name__ == "__main__":
    report()
    save_task_effects()
    save_downstream_heatmap()
