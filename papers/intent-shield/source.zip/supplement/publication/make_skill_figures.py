#!/usr/bin/env python3
"""Create publication-ready V3 figures from the frozen aggregate CSV files."""

from __future__ import annotations

import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch


ROOT = Path(__file__).resolve().parent
INPUTS = ROOT.parent / "figure_inputs"
OUTPUTS = ROOT / "plots" / "v3_skill"

COLORS = {
    "direct": "#0F4D92",
    "direct_light": "#8FB5D5",
    "intent": "#B64342",
    "intent_light": "#E9A6A1",
    "phase": "#3A7D44",
    "phase_light": "#AADCA9",
    "neutral": "#767676",
    "neutral_light": "#D9D9D9",
    "grid": "#D8DDE3",
    "ink": "#202428",
    "negative": "#A61E2D",
}


def apply_style() -> None:
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "font.size": 9.0,
            "axes.titlesize": 10.5,
            "axes.labelsize": 9.0,
            "axes.linewidth": 0.8,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "xtick.labelsize": 8.2,
            "ytick.labelsize": 8.2,
            "legend.fontsize": 8.2,
            "legend.frameon": False,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "savefig.facecolor": "white",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
        }
    )


def read_csv(name: str) -> list[dict[str, str]]:
    with (INPUTS / name).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def save_figure(fig: plt.Figure, basename: str) -> None:
    OUTPUTS.mkdir(parents=True, exist_ok=True)
    for suffix in ("pdf", "svg"):
        fig.savefig(
            OUTPUTS / f"{basename}.{suffix}",
            bbox_inches="tight",
            pad_inches=0.04,
        )
    fig.savefig(
        OUTPUTS / f"{basename}.png",
        dpi=600,
        bbox_inches="tight",
        pad_inches=0.04,
    )
    plt.close(fig)


def add_box(
    ax: plt.Axes,
    xy: tuple[float, float],
    width: float,
    height: float,
    text: str,
    edge: str,
    fill: str = "white",
    fontsize: float = 8.3,
    weight: str = "normal",
) -> None:
    patch = FancyBboxPatch(
        xy,
        width,
        height,
        boxstyle="round,pad=0.008,rounding_size=0.012",
        linewidth=1.2,
        edgecolor=edge,
        facecolor=fill,
    )
    ax.add_patch(patch)
    ax.text(
        xy[0] + width / 2,
        xy[1] + height / 2,
        text,
        ha="center",
        va="center",
        fontsize=fontsize,
        color=COLORS["ink"],
        weight=weight,
    )


def add_arrow(
    ax: plt.Axes,
    start: tuple[float, float],
    end: tuple[float, float],
    color: str = "#3F454B",
    linewidth: float = 1.0,
) -> None:
    arrow = FancyArrowPatch(
        start,
        end,
        arrowstyle="-|>",
        mutation_scale=10,
        linewidth=linewidth,
        color=color,
        shrinkA=1,
        shrinkB=1,
    )
    ax.add_patch(arrow)


def make_workflow() -> None:
    primary = read_csv("primary_summary.csv")
    overall = next(row for row in primary if row["group"] == "Overall")
    downstream = read_csv("downstream_summary.csv")
    phase_downstream = next(
        row for row in downstream if row["condition"] == "Phase-Revised"
    )

    fig, ax = plt.subplots(figsize=(7.05, 3.05))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    ax.text(
        0.18,
        0.91,
        "IntentShield: corrective feedback remains inside discovery",
        color=COLORS["intent"],
        fontsize=10.5,
        weight="bold",
        ha="left",
    )
    ax.text(
        0.18,
        0.47,
        "Phase-separated (same discovery as Direct): freeze evidence before repair",
        color=COLORS["phase"],
        fontsize=10.5,
        weight="bold",
        ha="left",
    )

    add_box(
        ax,
        (0.01, 0.39),
        0.125,
        0.23,
        "Intent\n+\nweakened\nspecification",
        COLORS["neutral"],
        "#F2F2F2",
        fontsize=8.0,
        weight="bold",
    )

    top_y = 0.64
    top_h = 0.17
    top_boxes = [
        (0.18, 0.18, "Iterative discovery\nwith feedback"),
        (0.41, 0.17, "Candidate revised\nbetween calls"),
        (0.63, 0.14, "Certify final\ncandidate"),
        (
            0.82,
            0.16,
            f"{int(float(overall['intentshield_successes']))}/"
            f"{int(float(overall['n_per_method']))}\ncertified witnesses",
        ),
    ]
    for x, width, text in top_boxes:
        fill = "#FBEDEE" if x == 0.82 else "white"
        add_box(ax, (x, top_y), width, top_h, text, COLORS["intent"], fill)
    for left, right in zip(top_boxes, top_boxes[1:]):
        add_arrow(
            ax,
            (left[0] + left[1], top_y + top_h / 2),
            (right[0], top_y + top_h / 2),
            COLORS["intent"],
        )

    bottom_y = 0.18
    bottom_h = 0.17
    bottom_boxes = [
        (0.18, 0.135, "No-feedback\ndiscovery"),
        (0.345, 0.13, "Freeze exact\ncandidate"),
        (0.515, 0.115, "Certify\nwitness"),
        (0.67, 0.125, "Repair\nspecification"),
        (0.835, 0.145, "Synthesize\nimplementation"),
    ]
    for x, width, text in bottom_boxes:
        fill = "#EEF6EF" if x in (0.515, 0.835) else "white"
        add_box(ax, (x, bottom_y), width, bottom_h, text, COLORS["phase"], fill)
    for left, right in zip(bottom_boxes, bottom_boxes[1:]):
        add_arrow(
            ax,
            (left[0] + left[1], bottom_y + bottom_h / 2),
            (right[0], bottom_y + bottom_h / 2),
            COLORS["phase"],
        )

    ax.plot(
        [0.495, 0.495],
        [0.145, 0.395],
        color=COLORS["ink"],
        linewidth=1.8,
    )
    ax.text(
        0.495,
        0.405,
        "frozen boundary",
        ha="center",
        va="bottom",
        fontsize=7.5,
        color=COLORS["ink"],
    )

    add_arrow(ax, (0.135, 0.52), (0.18, top_y + top_h / 2))
    add_arrow(ax, (0.135, 0.48), (0.18, bottom_y + bottom_h / 2))

    ax.text(
        0.572,
        0.135,
        f"{int(float(overall['phase_successes']))}/"
        f"{int(float(overall['n_per_method']))} certified",
        ha="center",
        va="top",
        fontsize=7.8,
        color=COLORS["phase"],
        weight="bold",
    )
    ax.text(
        0.907,
        0.135,
        f"{int(float(phase_downstream['successes']))}/"
        f"{int(float(phase_downstream['total_attempts']))} successful*",
        ha="center",
        va="top",
        fontsize=7.5,
        color=COLORS["phase"],
        weight="bold",
    )
    ax.text(
        0.985,
        0.025,
        "*Separate 16-task downstream evaluation.",
        ha="right",
        va="bottom",
        fontsize=7.2,
        color=COLORS["neutral"],
    )

    save_figure(fig, "intent_shield_workflow_v3")


def make_primary_dumbbell() -> None:
    rows = read_csv("primary_task_effects.csv")
    summary_rows = read_csv("primary_summary.csv")
    overall = next(row for row in summary_rows if row["group"] == "Overall")

    tasks = [row["task"] for row in rows]
    direct = np.array([float(row["direct_rate_pct"]) for row in rows])
    intent = np.array([float(row["intentshield_rate_pct"]) for row in rows])
    effects = np.array([float(row["direct_minus_intentshield_pp"]) for row in rows])
    y = np.arange(len(rows))

    fig, ax = plt.subplots(figsize=(7.05, 4.45))
    fig.subplots_adjust(left=0.22, right=0.985, top=0.84, bottom=0.16)

    for yi, left, right, effect in zip(y, intent, direct, effects):
        line_color = COLORS["negative"] if effect < 0 else COLORS["direct_light"]
        ax.plot(
            [left, right],
            [yi, yi],
            color=line_color,
            linewidth=1.7,
            zorder=1,
        )

    ax.scatter(
        direct,
        y,
        s=78,
        facecolor="white",
        edgecolor=COLORS["phase"],
        linewidth=2.0,
        zorder=3,
    )
    ax.scatter(
        direct,
        y,
        s=35,
        facecolor=COLORS["direct"],
        edgecolor="white",
        linewidth=0.5,
        zorder=4,
    )
    ax.scatter(
        intent,
        y,
        s=45,
        marker="s",
        facecolor=COLORS["intent"],
        edgecolor="white",
        linewidth=0.5,
        zorder=4,
    )

    ax.set_yticks(y, tasks)
    ax.invert_yaxis()
    ax.set_xlim(0, 128)
    ax.set_xticks(np.arange(0, 101, 20), [f"{value}%" for value in range(0, 101, 20)])
    ax.set_xlabel("Certified-witness success rate")
    ax.tick_params(axis="y", length=0)
    for x in np.arange(0, 101, 20):
        ax.axvline(x, color=COLORS["grid"], linewidth=0.7, zorder=0)
    ax.axhline(4.5, color="#AEB4BA", linewidth=0.8, linestyle=(0, (4, 3)))

    for yi, effect in zip(y, effects):
        color = COLORS["negative"] if effect < 0 else COLORS["ink"]
        ax.text(
            112,
            yi,
            f"{effect:+.1f} pp",
            ha="left",
            va="center",
            fontsize=8.1,
            color=color,
            weight="bold" if effect < 0 else "normal",
        )
    ax.text(
        112,
        -0.9,
        "Direct - IntentShield",
        ha="left",
        va="bottom",
        fontsize=8.3,
        weight="bold",
        color=COLORS["ink"],
    )

    ax.text(
        -0.155,
        0.80,
        "Residual\ncontract",
        transform=ax.transAxes,
        ha="center",
        va="center",
        fontsize=8.5,
        color=COLORS["phase"],
        weight="bold",
    )
    ax.text(
        -0.155,
        0.27,
        "Total\nomission",
        transform=ax.transAxes,
        ha="center",
        va="center",
        fontsize=8.5,
        color=COLORS["phase"],
        weight="bold",
    )

    legend_handles = [
        Line2D(
            [0],
            [0],
            marker="o",
            markersize=8.5,
            markerfacecolor=COLORS["direct"],
            markeredgecolor=COLORS["phase"],
            markeredgewidth=2.0,
            linestyle="none",
            label="Direct / Phase (identical)",
        ),
        Line2D(
            [0],
            [0],
            marker="s",
            markersize=7.0,
            markerfacecolor=COLORS["intent"],
            markeredgecolor=COLORS["intent"],
            linestyle="none",
            label="IntentShield",
        ),
    ]
    ax.legend(
        handles=legend_handles,
        loc="lower center",
        bbox_to_anchor=(0.47, 1.015),
        ncol=2,
        handletextpad=0.6,
        columnspacing=1.8,
    )
    ax.set_title(
        "Corrective feedback lowers witness yield on 11 of 12 tasks",
        loc="left",
        pad=30,
        weight="bold",
    )
    fig.text(
        0.54,
        0.035,
        "Overall: 59.0% vs 27.1%, difference +31.9 pp; "
        "95% task-bootstrap interval [21.5, 38.9]; "
        "exact sign test p = 0.00635.  n = 12 outcomes per method and task.",
        ha="center",
        va="center",
        fontsize=7.8,
        color=COLORS["ink"],
    )

    save_figure(fig, "primary_task_dumbbell_v3")


def make_downstream() -> None:
    gap_rows = read_csv("specification_gap.csv")
    summary_rows = read_csv("downstream_summary.csv")
    comparison_rows = read_csv("downstream_comparisons.csv")

    weak = next(row for row in gap_rows if row["stage"] == "Weak-contract Verus")
    restored = next(
        row for row in gap_rows if row["stage"] == "Restored-contract Verus"
    )

    conditions = [row["condition"] for row in summary_rows]
    rates = np.array([float(row["success_rate_pct"]) for row in summary_rows])
    successes = [int(float(row["successes"])) for row in summary_rows]
    totals = [int(float(row["total_attempts"])) for row in summary_rows]

    phase_original = next(
        row
        for row in comparison_rows
        if row["comparison"] == "Phase-Revised minus Original"
    )
    phase_intent = next(
        row
        for row in comparison_rows
        if row["comparison"] == "Phase-Revised minus IntentShield-Revised"
    )

    fig, axes = plt.subplots(
        1,
        2,
        figsize=(7.05, 3.55),
        gridspec_kw={"width_ratios": [0.78, 1.38]},
    )
    fig.subplots_adjust(left=0.075, right=0.985, top=0.83, bottom=0.18, wspace=0.43)
    ax_gap, ax_bars = axes

    gap_labels = ["Weakened\ncontract", "Restored\ncontract"]
    gap_rates = [float(weak["original_rate_pct"]), float(restored["original_rate_pct"])]
    gap_counts = [
        f"{int(float(weak['original_successes']))}/{int(float(weak['total']))}",
        f"{int(float(restored['original_successes']))}/{int(float(restored['total']))}",
    ]
    bars = ax_gap.bar(
        np.arange(2),
        gap_rates,
        width=0.58,
        color=[COLORS["neutral_light"], COLORS["neutral"]],
        edgecolor=COLORS["ink"],
        linewidth=0.8,
        hatch=["//", ""],
    )
    for bar, count, rate in zip(bars, gap_counts, gap_rates):
        ax_gap.text(
            bar.get_x() + bar.get_width() / 2,
            rate + 3.0,
            f"{count}\n({rate:.1f}%)",
            ha="center",
            va="bottom",
            fontsize=8.1,
            weight="bold",
        )
    ax_gap.annotate(
        "",
        xy=(0.5, gap_rates[1] + 2),
        xytext=(0.5, gap_rates[0] - 2),
        arrowprops={
            "arrowstyle": "<->",
            "color": COLORS["negative"],
            "linewidth": 1.4,
        },
    )
    ax_gap.text(
        0.58,
        np.mean(gap_rates),
        "58.3 pp\nspecification gap",
        ha="left",
        va="center",
        fontsize=8.2,
        color=COLORS["negative"],
        weight="bold",
    )
    ax_gap.set_xticks(np.arange(2), gap_labels)
    ax_gap.set_ylim(0, 112)
    ax_gap.set_yticks(np.arange(0, 101, 20), [f"{value}%" for value in range(0, 101, 20)])
    ax_gap.set_ylabel("Success rate")
    ax_gap.grid(axis="y", color=COLORS["grid"], linewidth=0.7)
    ax_gap.set_axisbelow(True)
    ax_gap.set_title(
        "A   Incomplete contracts hide failures",
        loc="left",
        weight="bold",
    )
    ax_gap.text(
        0.5,
        -0.20,
        "Original condition",
        transform=ax_gap.transAxes,
        ha="center",
        va="top",
        fontsize=7.8,
        color=COLORS["neutral"],
    )

    bar_colors = [COLORS["neutral"], COLORS["intent"], COLORS["phase"]]
    hatches = ["//", "xx", ""]
    bars = ax_bars.bar(
        np.arange(3),
        rates,
        width=0.58,
        color=bar_colors,
        edgecolor=COLORS["ink"],
        linewidth=0.8,
        hatch=hatches,
    )
    for bar, count, total, rate in zip(bars, successes, totals, rates):
        ax_bars.text(
            bar.get_x() + bar.get_width() / 2,
            rate + 2.8,
            f"{count}/{total}\n({rate:.1f}%)",
            ha="center",
            va="bottom",
            fontsize=8.1,
            weight="bold",
        )

    readable_labels = ["Original", "IS-Revised", "Phase-Revised"]
    ax_bars.set_xticks(np.arange(3), readable_labels)
    ax_bars.set_ylim(0, 122)
    ax_bars.set_yticks(np.arange(0, 101, 20), [f"{value}%" for value in range(0, 101, 20)])
    ax_bars.set_ylabel("Successful implementations")
    ax_bars.grid(axis="y", color=COLORS["grid"], linewidth=0.7)
    ax_bars.set_axisbelow(True)
    ax_bars.set_title(
        "B   Witness-preserving repair improves implementation",
        loc="left",
        weight="bold",
    )
    ax_bars.text(
        0.02,
        0.985,
        f"Phase - Original: +{float(phase_original['effect_pp']):.1f} pp "
        f"[{float(phase_original['ci_low_pp']):.1f}, "
        f"{float(phase_original['ci_high_pp']):.1f}], "
        f"p = {float(phase_original['exact_sign_p']):.6f}\n"
        f"Phase - IS-Revised: +{float(phase_intent['effect_pp']):.1f} pp "
        f"[{float(phase_intent['ci_low_pp']):.1f}, "
        f"{float(phase_intent['ci_high_pp']):.1f}], "
        f"p = {float(phase_intent['exact_sign_p']):.5f}",
        transform=ax_bars.transAxes,
        ha="left",
        va="top",
        fontsize=7.5,
        color=COLORS["ink"],
    )
    fig.text(
        0.66,
        0.035,
        "Task is the independent unit: 16 tasks x 3 attempts per condition.",
        ha="center",
        va="center",
        fontsize=7.7,
        color=COLORS["neutral"],
    )

    save_figure(fig, "downstream_spec_gap_v3")


def make_transfer() -> None:
    rows = read_csv("transfer_summary.csv")
    panels = [
        (
            "Verus",
            "Primary matrix\nn = 144 per method",
            ["Direct", "IntentShield", "Phase"],
            "Supported: Direct - IntentShield = +31.9 pp",
        ),
        (
            "Dafny",
            "Qwen stratum with headroom\nn = 24 per method",
            ["Direct", "IntentShield"],
            "Descriptive: Direct - IntentShield = -8.3 pp",
        ),
        (
            "Lean",
            "Held-out matrix\nn = 48 per method",
            ["No context", "Direct", "IntentShield", "Phase"],
            "No transfer support: Phase is the lowest arm",
        ),
    ]
    method_colors = {
        "No context": COLORS["neutral"],
        "Direct": COLORS["direct"],
        "IntentShield": COLORS["intent"],
        "Phase": COLORS["phase"],
    }
    method_hatches = {
        "No context": "//",
        "Direct": "",
        "IntentShield": "xx",
        "Phase": "..",
    }

    fig, axes = plt.subplots(1, 3, figsize=(7.05, 3.35), sharex=True)
    fig.subplots_adjust(left=0.09, right=0.985, top=0.77, bottom=0.31, wspace=0.56)

    for ax, (substrate, scope, methods, conclusion) in zip(axes, panels):
        substrate_rows = {
            row["method"]: row for row in rows if row["substrate"] == substrate
        }
        values = [float(substrate_rows[method]["success_rate_pct"]) for method in methods]
        y = np.arange(len(methods))
        bars = ax.barh(
            y,
            values,
            height=0.58,
            color=[method_colors[method] for method in methods],
            edgecolor=COLORS["ink"],
            linewidth=0.7,
            hatch=[method_hatches[method] for method in methods],
        )
        ax.set_yticks(y, methods)
        ax.invert_yaxis()
        ax.set_xlim(0, 112)
        ax.set_xticks([0, 50, 100], ["0%", "50%", "100%"])
        ax.grid(axis="x", color=COLORS["grid"], linewidth=0.7)
        ax.set_axisbelow(True)
        ax.tick_params(axis="y", length=0)
        for bar, method, value in zip(bars, methods, values):
            row = substrate_rows[method]
            count = int(float(row["successes"]))
            total = int(float(row["total"]))
            ax.text(
                min(value + 2.4, 103),
                bar.get_y() + bar.get_height() / 2,
                f"{count}/{total}",
                ha="left",
                va="center",
                fontsize=7.7,
                color=COLORS["ink"],
            )
        ax.set_title(substrate, loc="left", weight="bold", pad=28)
        ax.text(
            0.0,
            1.04,
            scope,
            transform=ax.transAxes,
            ha="left",
            va="bottom",
            fontsize=7.6,
            color=COLORS["neutral"],
        )
        conclusion_color = COLORS["direct"] if substrate == "Verus" else COLORS["negative"]
        short_conclusion = {
            "Verus": "Supported: D - IS = +31.9 pp",
            "Dafny": "Descriptive: D - IS = -8.3 pp",
            "Lean": "No support: Phase is lowest",
        }[substrate]
        ax.text(
            0.0,
            -0.24,
            short_conclusion,
            transform=ax.transAxes,
            ha="left",
            va="top",
            fontsize=7.4,
            color=conclusion_color,
            weight="bold",
        )

    fig.suptitle(
        "The Verus result does not reproduce across proof substrates",
        x=0.09,
        y=0.975,
        ha="left",
        fontsize=10.5,
        weight="bold",
    )
    fig.text(
        0.5,
        0.025,
        "Panels use different task matrices and are compared for direction and scope, "
        "not absolute difficulty.",
        ha="center",
        va="bottom",
        fontsize=7.6,
        color=COLORS["neutral"],
    )

    save_figure(fig, "transfer_scope_v3")


def make_mechanism() -> None:
    rows = read_csv("mechanism_summary.csv")
    parse_rows = [row for row in rows if row["panel"] == "Parse diagnostic"]
    parse_clean = next(row for row in rows if row["panel"] == "Parse-clean sensitivity")
    ablations = [row for row in rows if row["panel"] == "Format-matched ablation"]

    fig, axes = plt.subplots(
        1,
        2,
        figsize=(7.05, 3.25),
        gridspec_kw={"width_ratios": [0.85, 1.25]},
    )
    fig.subplots_adjust(left=0.085, right=0.985, top=0.76, bottom=0.25, wspace=0.42)
    ax_parse, ax_ablation = axes

    methods = [row["method_or_channel"] for row in parse_rows]
    parse_rates = [float(row["rate_or_effect_pp"]) for row in parse_rows]
    counts = [
        f"{int(float(row['numerator']))}/{int(float(row['denominator']))}"
        for row in parse_rows
    ]
    bars = ax_parse.bar(
        np.arange(2),
        parse_rates,
        width=0.58,
        color=[COLORS["direct"], COLORS["intent"]],
        edgecolor=COLORS["ink"],
        linewidth=0.8,
        hatch=["", "xx"],
    )
    for bar, count, rate in zip(bars, counts, parse_rates):
        ax_parse.text(
            bar.get_x() + bar.get_width() / 2,
            rate + 1.5,
            f"{count}\n({rate:.1f}%)",
            ha="center",
            va="bottom",
            fontsize=8.0,
            weight="bold",
        )
    ax_parse.set_xticks(np.arange(2), methods)
    ax_parse.set_ylim(0, 44)
    ax_parse.set_yticks([0, 10, 20, 30, 40], ["0%", "10%", "20%", "30%", "40%"])
    ax_parse.set_ylabel("Episodes with any parse failure")
    ax_parse.grid(axis="y", color=COLORS["grid"], linewidth=0.7)
    ax_parse.set_axisbelow(True)
    ax_parse.set_title("A   Parse behavior", loc="left", weight="bold")
    ax_parse.text(
        0.5,
        -0.20,
        "IntentShield has 23.6 pp more parse failures.",
        transform=ax_parse.transAxes,
        ha="center",
        va="top",
        fontsize=7.5,
        color=COLORS["negative"],
        weight="bold",
    )

    labels = ["Verifier feedback", "Visible-test feedback"]
    effects = [
        float(row["rate_or_effect_pp"])
        for row in sorted(
            ablations,
            key=lambda row: 0
            if "verifier" in row["metric"].lower()
            else 1,
        )
    ]
    sorted_ablations = sorted(
        ablations,
        key=lambda row: 0 if "verifier" in row["metric"].lower() else 1,
    )
    y = np.arange(2)
    ax_ablation.axvline(0, color=COLORS["ink"], linewidth=0.9)
    for yi, effect, row in zip(y, effects, sorted_ablations):
        ax_ablation.plot(
            [effect, 0],
            [yi, yi],
            color=COLORS["intent_light"],
            linewidth=2.0,
        )
        ax_ablation.scatter(
            [effect],
            [yi],
            s=60,
            facecolor=COLORS["intent"],
            edgecolor="white",
            linewidth=0.7,
            zorder=3,
        )
        ax_ablation.text(
            effect,
            yi - 0.18,
            f"{effect:.1f} pp  (p = {float(row['exact_task_p']):.4g})",
            ha="center",
            va="bottom",
            fontsize=7.8,
            weight="bold",
        )
    ax_ablation.set_yticks(y, labels)
    ax_ablation.set_ylim(1.35, -0.45)
    ax_ablation.set_xlim(-40, 8)
    ax_ablation.set_xticks([-40, -30, -20, -10, 0], ["-40", "-30", "-20", "-10", "0"])
    ax_ablation.set_xlabel(
        "Change in certified-witness rate when feedback is added (pp)"
    )
    ax_ablation.grid(axis="x", color=COLORS["grid"], linewidth=0.7)
    ax_ablation.set_axisbelow(True)
    ax_ablation.tick_params(axis="y", length=0)
    ax_ablation.set_title(
        "B   Format-matched ablations",
        loc="left",
        weight="bold",
    )
    ax_ablation.text(
        0.98,
        0.02,
        "Point estimates only",
        transform=ax_ablation.transAxes,
        ha="right",
        va="bottom",
        fontsize=7.4,
        color=COLORS["neutral"],
    )

    fig.suptitle(
        "Mechanism diagnostics are descriptive, not causal",
        x=0.085,
        y=0.98,
        ha="left",
        fontsize=10.5,
        weight="bold",
    )
    fig.text(
        0.5,
        0.035,
        "After restricting to parse-clean episodes, Direct retains a "
        f"{float(parse_clean['rate_or_effect_pp']):.1f} pp certified-witness advantage. "
        "This is descriptive because parse success is post-treatment.",
        ha="center",
        va="center",
        fontsize=7.5,
        color=COLORS["neutral"],
    )

    save_figure(fig, "mechanism_diagnostics_v3")


def main() -> None:
    apply_style()
    make_workflow()
    make_primary_dumbbell()
    make_downstream()
    make_transfer()
    make_mechanism()
    print(f"Wrote publication figures to {OUTPUTS}")


if __name__ == "__main__":
    main()
