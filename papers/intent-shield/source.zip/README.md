# When Correctness Feedback Erases Evidence

Public camera-ready manuscript for:

> When Correctness Feedback Erases Evidence: Phase-Separated Completeness
> Auditing in Verus

## Build

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error paper.tex
```

The document uses a compact, letter-sized two-column research-paper layout.
The scientific content is carried forward from the workshop manuscript. The
submission checklist and anonymous author block are intentionally excluded
from this public version.

## Companion Analysis

The `supplement/` directory contains the retained task-level inputs and scripts
for reproducing the reported aggregate statistics and figures without model
calls.
